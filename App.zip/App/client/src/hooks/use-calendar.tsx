import { useState, useEffect } from 'react';
import { CalendarEvent } from '@/types';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

export function useCalendarEvents(date: Date) {
  const [events, setEvents] = useState<CalendarEvent[]>([]);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const loadEvents = async () => {
      try {
        setLoading(true);
        
        // Format date for query parameter
        const formattedDate = date.toISOString().split('T')[0]; // YYYY-MM-DD
        
        // Request gets proxied to FastAPI backend by Express
        const response = await apiRequest('GET', `/api/calendar-events?date=${formattedDate}`);
        
        if (!response.ok) {
          throw new Error('API request failed');
        }
        
        const data = await response.json();
        setEvents(data.events);
        
        setLoading(false);
      } catch (error) {
        console.error('Failed to load calendar events:', error);
        toast({
          title: 'Error loading calendar',
          description: 'Failed to load your calendar events. Please try again.',
          variant: 'destructive',
        });
        setLoading(false);
      }
    };

    loadEvents();
  }, [date, toast]);

  return {
    events,
    loading,
  };
}
