#!/bin/bash

# Print debug information
echo "Starting Python FastAPI backend..."
echo "Current directory: $(pwd)"
echo "Python version: $(python --version)"

# Make the script stop if any command fails
set -e

# Navigate to the Python backend directory
cd python_backend || { echo "Failed to change to python_backend directory"; exit 1; }
echo "Changed to directory: $(pwd)"

# Verify the main.py file exists
if [ ! -f "main.py" ]; then
  echo "Error: main.py not found in $(pwd)"
  exit 1
fi

# Ensure python dependencies are installed
echo "Installing dependencies..."
pip install --no-input -q fastapi uvicorn python-dotenv pydantic httpx openai langchain requests

# Start the server
echo "Starting FastAPI server on port 8000..."
python -m uvicorn main:app --host 0.0.0.0 --port 8000 --log-level info