import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import axios from "axios";

// FastAPI backend URL
const FASTAPI_URL = process.env.FASTAPI_URL || "http://localhost:8000";
console.log("Using FastAPI backend URL:", FASTAPI_URL);

// Helper function to proxy requests to FastAPI
async function proxyToFastAPI(req: Request, res: Response, endpoint: string) {
  try {
    const url = `${FASTAPI_URL}${endpoint}`;
    console.log(`Proxying request to FastAPI: ${url}`);
    
    const method = req.method.toLowerCase();
    let response: any;
    
    const axiosConfig = {
      timeout: 5000, // 5 seconds timeout
      headers: {
        'Content-Type': 'application/json'
      }
    };
    
    if (method === 'get') {
      // Forward query parameters
      response = await axios.get(url, { 
        ...axiosConfig,
        params: req.query
      });
    } else if (method === 'post') {
      // Forward request body for POST
      response = await axios.post(url, req.body, axiosConfig);
    } else if (method === 'put') {
      // Forward request body for PUT
      response = await axios.put(url, req.body, axiosConfig);
    } else if (method === 'delete') {
      // Forward request body for DELETE
      response = await axios.delete(url, {
        ...axiosConfig,
        data: req.body
      });
    } else {
      throw new Error(`Unsupported HTTP method: ${method}`);
    }
    
    return res.status(response.status).json(response.data);
  } catch (error) {
    console.error('Error connecting to Python backend:', error);
    console.log('To use the application, make sure the Python backend is running:');
    console.log('  ./run_python_backend.sh');
    
    if (axios.isAxiosError(error) && error.response) {
      // Return the error response from the FastAPI server
      return res.status(error.response.status).json(error.response.data);
    }
    
    // For network errors or other issues
    return res.status(500).json({ 
      error: 'Failed to connect to ExploreEase AI backend',
      message: 'Please make sure the Python backend is running with ./run_python_backend.sh'
    });
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // API Routes
  app.get('/api/health-check', (req, res) => {
    res.json({ status: 'express_ok' });
  });
  
  // Health check endpoint for the Python FastAPI backend
  app.get('/api/python-health', async (req, res) => {
    try {
      // Try to connect to the Python backend
      const response = await axios.get(`${FASTAPI_URL}/health-check`, {
        timeout: 2000 // Short timeout
      });
      
      if (response.status === 200) {
        return res.json({ status: 'ok', python: true });
      } else {
        return res.status(503).json({ status: 'error', python: false });
      }
    } catch (error) {
      console.log('Python backend health check failed:', error instanceof Error ? error.message : 'Unknown error');
      return res.status(200).json({ status: 'ok', python: false });
    }
  });
  
  // Calendar events routes - proxy to Python FastAPI
  app.get('/api/calendar-events', async (req, res) => {
    try {
      console.log("Proxying calendar events request to Python backend");
      await proxyToFastAPI(req, res, '/api/calendar-events');
    } catch (error) {
      console.error('Calendar events error:', error);
      res.status(500).json({ 
        error: 'Failed to fetch calendar events',
        message: 'Make sure the Python backend is running with ./run_python_backend.sh'
      });
    }
  });
  
  // Recommendations routes - proxy to Python FastAPI
  app.post('/api/recommendations', async (req, res) => {
    try {
      // Validate basic input
      const data = req.body;
      if (!data.travelPurpose || !data.transportation || !data.budget || !data.destination) {
        res.status(400).json({ error: 'Missing required preferences' });
        return;
      }
      
      console.log("Proxying recommendations request to Python backend");
      await proxyToFastAPI(req, res, '/api/recommendations');
    } catch (error) {
      console.error('Recommendations error:', error);
      res.status(500).json({ 
        error: 'Failed to generate recommendations',
        message: 'Make sure the Python backend is running with ./run_python_backend.sh'
      });
    }
  });
  
  // Add to calendar route - proxy to Python FastAPI
  app.post('/api/add-to-calendar', async (req, res) => {
    try {
      console.log("Proxying add-to-calendar request to Python backend");
      await proxyToFastAPI(req, res, '/api/add-to-calendar');
    } catch (error) {
      console.error('Add to calendar error:', error);
      res.status(500).json({ 
        error: 'Failed to add event to calendar',
        message: 'Make sure the Python backend is running with ./run_python_backend.sh'
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
