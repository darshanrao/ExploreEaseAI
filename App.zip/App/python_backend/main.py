import os
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
import uvicorn
from dotenv import load_dotenv

# Import agent modules
from agents import calendar_api, info_agent

# Load environment variables
load_dotenv()

app = FastAPI(title="ExploreEase AI API", description="AI Travel Planning API")

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # For development - restrict this in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Models for request/response
class FoodPreference(BaseModel):
    id: str
    text: str

class ActivityInterest(BaseModel):
    id: str
    text: str

class PreferencesRequest(BaseModel):
    travelPurpose: str
    transportation: str
    budget: float
    destination: str
    startDate: str
    endDate: str
    foodPreferences: List[FoodPreference]
    activityInterests: List[ActivityInterest]

class Location(BaseModel):
    lat: float
    lng: float

class Recommendation(BaseModel):
    id: str
    name: str
    category: str
    type: str
    rating: float
    reviewCount: int
    priceLevel: str
    cuisine: str
    distance: float
    description: str
    matchesPreferences: bool
    location: Location

class RecommendationsResponse(BaseModel):
    recommendations: List[Recommendation]

class CalendarEvent(BaseModel):
    id: str
    title: str
    startTime: str
    endTime: str
    location: Optional[str] = None
    type: str  # 'location' | 'food' | 'virtual' | 'other'
    category: str  # 'work' | 'personal' | 'other'

class CalendarEventsResponse(BaseModel):
    events: List[CalendarEvent]

# Routes
@app.get("/")
async def root():
    return {"message": "Welcome to ExploreEase AI API"}

@app.get("/api/health")
async def health_check():
    return {"status": "ok"}

@app.get("/health-check")
async def health_check_endpoint():
    return {"status": "python_ok"}

@app.post("/api/recommendations", response_model=RecommendationsResponse)
async def get_recommendations(preferences: PreferencesRequest):
    try:
        # Use the info_agent to get recommendations
        recommendations = info_agent.get_recommendations(preferences.dict())
        
        if not recommendations:
            raise HTTPException(
                status_code=500, 
                detail="Could not generate recommendations. Please check your OpenAI API key and try again."
            )
        
        return {"recommendations": recommendations}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to generate recommendations: {str(e)}")

@app.get("/api/calendar-events", response_model=CalendarEventsResponse)
async def get_calendar_events(date: Optional[str] = None):
    try:
        # Get date from query parameter, defaulting to today
        # Use the calendar_api to get events
        events = calendar_api.get_events(date)
        
        if not events:
            raise HTTPException(
                status_code=500, 
                detail="Could not retrieve calendar events. Please check your API key and try again."
            )
        
        return {"events": events}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch calendar events: {str(e)}")

class AddToCalendarRequest(BaseModel):
    title: str
    description: Optional[str] = None
    location: Optional[str] = None
    startTime: str
    endTime: str
    timeZone: Optional[str] = "UTC"

class CalendarResponse(BaseModel):
    success: bool
    message: str
    eventId: Optional[str] = None

@app.post("/api/add-to-calendar", response_model=CalendarResponse)
async def add_to_calendar(event: AddToCalendarRequest):
    try:
        # Here we would typically use the Google Calendar API to add the event
        # Since we don't have direct calendar integration yet, we'll use our
        # calendar_api.add_event() function which will simulate the addition
        # or use OpenAI to generate a response about the event
        
        # For future implementation: Replace with calendar API integration
        # Add a proper calendar_api.add_event() method when implementing
        # Google Calendar API integration
        
        # For now return a success response
        return {
            "success": True,
            "message": "Event successfully added to your travel plan",
            "eventId": "event_" + str(hash(event.startTime + event.title) % 10000)
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to add event to travel plan: {str(e)}")

# Run the server directly if this file is executed
if __name__ == "__main__":
    # Get port from environment variable or use default
    port = int(os.environ.get("PORT", 8000))
    
    print(f"Starting FastAPI server on port {port}")
    uvicorn.run("main:app", host="0.0.0.0", port=port, reload=True)