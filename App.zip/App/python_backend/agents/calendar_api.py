"""
Calendar API Agent for fetching and managing calendar events

This module handles integrating with calendar services to fetch and process
scheduled events for the user.
"""

import os
import json
import uuid
from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta
import random

# Handle dependency imports safely
try:
    from pydantic import BaseModel
    PYDANTIC_AVAILABLE = True
except ImportError:
    print("Pydantic package not installed. Using dict-based fallback.")
    PYDANTIC_AVAILABLE = False
    # Create a simple BaseModel alternative
    class BaseModel:
        def __init__(self, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)
        
        def dict(self):
            return self.__dict__

# Try to load dotenv
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    print("python-dotenv package not installed. Environment variables must be set manually.")

# Try to import OpenAI
try:
    from openai import OpenAI
    OPENAI_AVAILABLE = True
except ImportError:
    print("OpenAI package not installed. Using fallback implementation.")
    OPENAI_AVAILABLE = False

class CalendarEvent(BaseModel):
    """Model for a calendar event"""
    id: str
    title: str
    startTime: str
    endTime: str
    location: Optional[str] = None
    type: str  # 'location' | 'food' | 'virtual' | 'other'
    category: str  # 'work' | 'personal' | 'other'

def parse_date(date_str: Optional[str] = None) -> datetime:
    """Parse the date string into a datetime object"""
    if not date_str:
        return datetime.now()
        
    try:
        # Try to parse as ISO format YYYY-MM-DD
        return datetime.fromisoformat(date_str)
    except ValueError:
        try:
            # Try to parse as ISO format with time
            return datetime.fromisoformat(date_str.replace('Z', '+00:00'))
        except ValueError:
            print(f"Could not parse date: {date_str}, using current date")
            return datetime.now()

def generate_with_openai(date: datetime) -> List[Dict[str, Any]]:
    """Use OpenAI to generate calendar events"""
    
    # Check for API key
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        print("OpenAI API key not found. Please set OPENAI_API_KEY in environment variables.")
        return []
    
    # Format the date for the prompt
    date_str = date.strftime("%Y-%m-%d")
    day_of_week = date.strftime("%A")
    
    # Create client
    client = OpenAI(api_key=api_key)
    
    prompt = f"""
    Generate a realistic daily calendar schedule for {date_str} ({day_of_week}).
    
    Create 4-6 calendar events throughout the day, including a mix of:
    - Work meetings or commitments
    - Meal times (breakfast, lunch, dinner)
    - Personal appointments or activities
    - Travel or commute time
    
    Return the schedule as a valid JSON array with each item having this structure:
    {{
      "title": "Event title",
      "startTime": "ISO datetime with timezone (YYYY-MM-DDThh:mm:ss.sssZ)",
      "endTime": "ISO datetime with timezone (YYYY-MM-DDThh:mm:ss.sssZ)",
      "location": "Location name or address (optional)",
      "type": "One of: location, food, virtual, other",
      "category": "One of: work, personal, other"
    }}
    
    Ensure the response is ONLY the JSON array with no additional text.
    Make the schedule realistic with appropriate time gaps between events.
    Ensure all events happen on {date_str}.
    """
    
    try:
        # Call the OpenAI API
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a personal assistant that generates realistic daily calendar schedules formatted as JSON data."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.7,
            max_tokens=1000
        )
        
        # Extract the response content
        events_text = response.choices[0].message.content
        
        # Clean the response to ensure it's valid JSON
        events_text = events_text.strip()
        
        # Remove any markdown formatting if present
        if events_text.startswith("```json"):
            events_text = events_text.replace("```json", "", 1)
        if events_text.endswith("```"):
            events_text = events_text.replace("```", "", 1)
        
        events_text = events_text.strip()
        
        # Parse the JSON response
        try:
            events_data = json.loads(events_text)
            
            # Assign unique IDs to each event
            for event in events_data:
                event["id"] = str(uuid.uuid4())[:8]
                
            return events_data
            
        except json.JSONDecodeError as e:
            print(f"Failed to decode JSON from OpenAI response: {e}")
            print(f"Raw response: {events_text}")
            return []
        
    except Exception as e:
        print(f"Error generating calendar events with OpenAI: {str(e)}")
        return []

# This function has been removed as it used synthetic data

def get_events(date_str: Optional[str] = None) -> List[Dict[str, Any]]:
    """
    Get calendar events for a specific date
    
    Args:
        date_str: Date string in ISO format (YYYY-MM-DD), defaults to today
        
    Returns:
        List of calendar events
    """
    # Parse the input date
    date = parse_date(date_str)
    formatted_date = date.strftime("%Y-%m-%d")
    
    print(f"Fetching calendar events for date: {formatted_date}")
    
    # Try to use OpenAI if available
    if OPENAI_AVAILABLE and os.getenv("OPENAI_API_KEY"):
        try:
            events = generate_with_openai(date)
            if events:
                return events
        except Exception as e:
            print(f"OpenAI calendar event generation failed: {str(e)}")
    
    # If we reach here, we couldn't generate events with OpenAI
    print("Could not generate calendar events with OpenAI API.")
    return []