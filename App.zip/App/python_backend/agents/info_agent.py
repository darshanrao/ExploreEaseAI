"""
Information Agent for generating travel recommendations based on user preferences

This agent uses OpenAI API to generate personalized recommendations for travelers
"""

import os
import json
import uuid
import random
from typing import Dict, List, Any, Optional

# Handle dependency imports safely
try:
    from pydantic import BaseModel
    PYDANTIC_AVAILABLE = True
except ImportError:
    print("Pydantic package not installed. Using dict-based fallback.")
    PYDANTIC_AVAILABLE = False
    # Create a simple BaseModel alternative
    class BaseModel:
        def __init__(self, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)
        
        def dict(self):
            return self.__dict__

# Try to load dotenv
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    print("python-dotenv package not installed. Environment variables must be set manually.")

# Try to import OpenAI
try:
    from openai import OpenAI
    OPENAI_AVAILABLE = True
except ImportError:
    print("OpenAI package not installed. Using fallback implementation.")
    OPENAI_AVAILABLE = False

class Recommendation(BaseModel):
    """Model for a recommendation"""
    id: str
    name: str
    category: str
    type: str
    rating: float
    reviewCount: int
    priceLevel: str
    cuisine: str
    distance: float
    description: str
    matchesPreferences: bool
    location: Dict[str, float]  # {'lat': float, 'lng': float}

def format_food_preferences(prefs: List[Dict]) -> str:
    """Format food preferences for the prompt"""
    if not prefs:
        return "No specific food preferences"
    return ", ".join([item["text"] for item in prefs])

def format_activity_interests(interests: List[Dict]) -> str:
    """Format activity interests for the prompt"""
    if not interests:
        return "No specific activity interests"
    return ", ".join([item["text"] for item in interests])

def generate_price_level(budget: float) -> str:
    """Generate price level indicators based on budget"""
    if budget < 50:
        return "$"
    elif budget < 150:
        return "$$"
    elif budget < 300:
        return "$$$"
    else:
        return "$$$$"

def generate_with_openai(preferences: Dict[str, Any]) -> List[Recommendation]:
    """Use OpenAI to generate recommendations"""
    
    # Check for API key
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        print("OpenAI API key not found. Please set OPENAI_API_KEY in environment variables.")
        return []
    
    # Format the prompt
    food_prefs = format_food_preferences(preferences.get("foodPreferences", []))
    activity_interests = format_activity_interests(preferences.get("activityInterests", []))
    travel_purpose = preferences.get("travelPurpose", "leisure")
    transportation = preferences.get("transportation", "walking")
    budget = preferences.get("budget", 100)
    date = preferences.get("date", "today")
    
    # Create client
    client = OpenAI(api_key=api_key)
    
    prompt = f"""
    Generate 5 location recommendations for a traveler with the following preferences:
    - Travel purpose: {travel_purpose}
    - Transportation mode: {transportation}
    - Budget: ${budget}
    - Food preferences: {food_prefs}
    - Activity interests: {activity_interests}
    - Date: {date}
    
    Return the recommendations as a valid JSON array with each item having this structure:
    {{
      "name": "Location name",
      "category": "restaurant/event/attraction/transport",
      "type": "specific type (cafe, museum, park, etc.)",
      "rating": "rating between 3.0 and 5.0",
      "reviewCount": "number of reviews (integer between 20 and 500)",
      "priceLevel": "price level ($ to $$$$)",
      "cuisine": "cuisine type for restaurants or N/A",
      "distance": "distance in miles (float between 0.1 and 5.0)",
      "description": "detailed description including why it matches preferences",
      "matchesPreferences": true,
      "lat": "latitude (float between 40.7 and 40.8)",
      "lng": "longitude (float between -74.1 and -73.9)"
    }}
    
    Ensure the response is ONLY the JSON array with no additional text.
    Make recommendations diverse across categories.
    """
    
    try:
        # Call the OpenAI API
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a travel recommendation assistant that provides location suggestions formatted as JSON data."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.7,
            max_tokens=1500
        )
        
        # Extract the response content
        recommendation_text = response.choices[0].message.content
        
        # Clean the response to ensure it's valid JSON
        recommendation_text = recommendation_text.strip()
        
        # Remove any markdown formatting if present
        if recommendation_text.startswith("```json"):
            recommendation_text = recommendation_text.replace("```json", "", 1)
        if recommendation_text.endswith("```"):
            recommendation_text = recommendation_text.replace("```", "", 1)
        
        recommendation_text = recommendation_text.strip()
        
        # Parse the JSON response
        recommendations_data = json.loads(recommendation_text)
        
        # Convert to list of Recommendation objects
        result = []
        for idx, rec in enumerate(recommendations_data):
            # Ensure we have location as a nested object
            if "lat" in rec and "lng" in rec:
                location = {"lat": rec.pop("lat"), "lng": rec.pop("lng")}
            else:
                location = {"lat": 40.7 + random.uniform(0, 0.1), "lng": -74.0 + random.uniform(0, 0.1)}
            
            recommendation = Recommendation(
                id=str(uuid.uuid4())[:8],
                name=rec.get("name", f"Recommendation {idx+1}"),
                category=rec.get("category", "restaurant"),
                type=rec.get("type", "cafe"),
                rating=rec.get("rating", round(random.uniform(3.5, 5.0), 1)),
                reviewCount=rec.get("reviewCount", random.randint(20, 300)),
                priceLevel=rec.get("priceLevel", generate_price_level(budget)),
                cuisine=rec.get("cuisine", "Various"),
                distance=rec.get("distance", round(random.uniform(0.1, 3.0), 1)),
                description=rec.get("description", "A great place to visit based on your preferences."),
                matchesPreferences=rec.get("matchesPreferences", True),
                location=location
            )
            result.append(recommendation)
        
        return result
        
    except Exception as e:
        print(f"Error generating recommendations with OpenAI: {str(e)}")
        return []

def get_recommendations(preferences: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Generate recommendations based on user preferences
    
    Args:
        preferences: User preferences including travel purpose, transportation, budget, etc.
        
    Returns:
        List of recommendations
    """
    print(f"Generating recommendations with preferences: {preferences}")
    
    # Try to use OpenAI if available
    if OPENAI_AVAILABLE and os.getenv("OPENAI_API_KEY"):
        try:
            recommendations = generate_with_openai(preferences)
            if recommendations:
                # Convert to dictionaries for JSON serialization
                return [rec.dict() for rec in recommendations]
        except Exception as e:
            print(f"OpenAI recommendation generation failed: {str(e)}")
    
    # If we reach here, we couldn't generate recommendations with OpenAI
    print("Could not generate recommendations with OpenAI API.")
    return []