import { InfoIcon, MapPinIcon, PieChartIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

export default function AgentExplanation() {
  const { toast } = useToast();

  const handleProvideFeedback = () => {
    toast({
      title: "Thank you for your feedback",
      description: "Your feedback helps us improve our recommendations",
      duration: 3000,
    });
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-4">
      <h3 className="font-medium flex items-center text-gray-900">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary mr-2" viewBox="0 0 20 20" fill="currentColor">
          <path fillRule="evenodd" d="M9.504 1.132a1 1 0 01.992 0l1.75 1a1 1 0 11-.992 1.736L10 3.152l-1.254.716a1 1 0 11-.992-1.736l1.75-1zM5.618 4.504a1 1 0 01-.372 1.364L5.016 6l.23.132a1 1 0 11-.992 1.736L4 7.723V8a1 1 0 01-2 0V6a.996.996 0 01.52-.878l1.734-.99a1 1 0 011.364.372zm8.764 0a1 1 0 011.364-.372l1.733.99A1.002 1.002 0 0118 6v2a1 1 0 11-2 0v-.277l-.254.145a1 1 0 11-.992-1.736l.23-.132-.23-.132a1 1 0 01-.372-1.364zm-7 4a1 1 0 011.364-.372L10 8.848l1.254-.716a1 1 0 11.992 1.736L11 10.58V12a1 1 0 11-2 0v-1.42l-1.246-.712a1 1 0 01-.372-1.364zM3 11a1 1 0 011 1v1.42l1.246.712a1 1 0 11-.992 1.736l-1.75-1A1 1 0 012 14v-2a1 1 0 011-1zm14 0a1 1 0 011 1v2a1 1 0 01-.504.868l-1.75 1a1 1 0 11-.992-1.736L16 13.42V12a1 1 0 011-1zm-9.618 5.504a1 1 0 011.364-.372l.254.145V16a1 1 0 112 0v.277l.254-.145a1 1 0 11.992 1.736l-1.735.992a.995.995 0 01-1.022 0l-1.735-.992a1 1 0 01-.372-1.364z" clipRule="evenodd" />
        </svg>
        How ExploreEase AI creates your recommendations
      </h3>
      <div className="mt-2 text-sm text-gray-600">
        <p>Our multi-agent system analyzes your travel preferences and schedule using specialized AI agents:</p>
        <ul className="mt-2 space-y-1.5">
          <li className="flex items-start">
            <InfoIcon className="h-4 w-4 text-primary mt-0.5 mr-1.5" />
            <span><b>InfoAgent</b> processes your preferences like cuisine types and activity interests.</span>
          </li>
          <li className="flex items-start">
            <MapPinIcon className="h-4 w-4 text-primary mt-0.5 mr-1.5" />
            <span><b>MapAgent</b> finds optimal locations for your selected destination.</span>
          </li>
          <li className="flex items-start">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-primary mt-0.5 mr-1.5" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clipRule="evenodd" />
            </svg>
            <span><b>CalendarAgent</b> syncs with your Google Calendar and schedules your trip.</span>
          </li>
          <li className="flex items-start">
            <PieChartIcon className="h-4 w-4 text-primary mt-0.5 mr-1.5" />
            <span><b>TravelPlannerAgent</b> optimizes your itinerary based on all the collected data.</span>
          </li>
        </ul>
      </div>
      <div className="mt-3">
        <Button 
          variant="link" 
          className="text-primary p-0 h-auto text-sm"
          onClick={handleProvideFeedback}
        >
          Provide feedback
          <svg xmlns="http://www.w3.org/2000/svg" className="ml-1 h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
            <path d="M2 10.5a1.5 1.5 0 113 0v6a1.5 1.5 0 01-3 0v-6zM6 10.333v5.43a2 2 0 001.106 1.79l.05.025A4 4 0 008.943 18h5.416a2 2 0 001.962-1.608l1.2-6A2 2 0 0015.56 8H12V4a2 2 0 00-2-2 1 1 0 00-1 1v.667a4 4 0 01-.8 2.4L6.8 7.933a4 4 0 00-.8 2.4z" />
          </svg>
        </Button>
      </div>
    </div>
  );
}
