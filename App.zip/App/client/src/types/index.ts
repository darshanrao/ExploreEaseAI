export interface CalendarEvent {
  id: string;
  title: string;
  startTime: string;
  endTime: string;
  location?: string;
  type: 'location' | 'food' | 'virtual' | 'other';
  category: 'work' | 'personal' | 'other';
}

export interface Recommendation {
  id: string;
  name: string;
  category: string;
  type: string;
  rating: number;
  reviewCount: number;
  priceLevel: string;
  cuisine: string;
  distance: number;
  description: string;
  matchesPreferences: boolean;
  location: {
    lat: number;
    lng: number;
  };
}

export interface PreferencesSubmitData {
  travelPurpose: string;
  transportation: string;
  budget: number;
  foodPreferences: string[];
  activityInterests: string[];
  destination: string;
  startDate: string;
  endDate: string;
}
