import { useState } from "react";
import { ChevronLeftIcon, ChevronRightIcon, MapPinIcon, UtensilsIcon, Video } from "lucide-react";
import { Button } from "@/components/ui/button";
import { CalendarEvent } from "@/types";
import { formatDate } from "@/lib/utils";

interface CalendarViewProps {
  events: CalendarEvent[];
  currentDate: Date;
  onDateChange: (date: Date) => void;
}

export default function CalendarView({ events, currentDate, onDateChange }: CalendarViewProps) {
  const eventIcons: Record<string, JSX.Element> = {
    location: <MapPinIcon className="h-4 w-4 text-gray-400" />,
    food: <UtensilsIcon className="h-4 w-4 text-gray-400" />,
    virtual: <Video className="h-4 w-4 text-gray-400" />,
  };

  const handlePrevDay = () => {
    const newDate = new Date(currentDate);
    newDate.setDate(newDate.getDate() - 1);
    onDateChange(newDate);
  };

  const handleNextDay = () => {
    const newDate = new Date(currentDate);
    newDate.setDate(newDate.getDate() + 1);
    onDateChange(newDate);
  };

  return (
    <div className="mb-12 bg-white rounded-lg shadow-sm overflow-hidden">
      <div className="p-6 border-b border-gray-200">
        <h2 className="text-2xl font-bold">Your Schedule</h2>
        <p className="text-gray-600">DayGenie will analyze these events to make personalized recommendations</p>
      </div>
      
      <div className="px-6 py-4 bg-gray-50 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-medium">{formatDate(currentDate, 'EEEE, MMMM d, yyyy')}</h3>
            <p className="text-sm text-gray-500">{events.length} events scheduled</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={handlePrevDay}>
              <ChevronLeftIcon className="h-4 w-4 mr-1" /> Previous
            </Button>
            <Button variant="outline" size="sm" onClick={handleNextDay}>
              Next <ChevronRightIcon className="h-4 w-4 ml-1" />
            </Button>
          </div>
        </div>
      </div>
      
      <div className="p-6">
        {events.length > 0 ? (
          <div className="space-y-4">
            {events.map((event) => (
              <div
                key={event.id}
                className="calendar-event flex p-3 rounded-lg border border-gray-200 hover:border-primary hover:bg-indigo-50 transition-colors duration-200"
              >
                <div className="flex flex-col items-center justify-center w-16 mr-4">
                  <span className="text-sm font-medium text-gray-500">
                    {formatDate(new Date(event.startTime), 'HH:mm')}
                  </span>
                  <span className="text-sm font-medium text-gray-500">
                    {formatDate(new Date(event.endTime), 'HH:mm')}
                  </span>
                </div>
                <div className="flex-1">
                  <h4 className="font-medium text-gray-900">{event.title}</h4>
                  <div className="mt-1 flex items-center text-sm text-gray-500">
                    {eventIcons[event.type] || <MapPinIcon className="h-4 w-4 text-gray-400 mr-1.5" />}
                    <span>{event.location || 'Not Specified'}</span>
                  </div>
                </div>
                <div className="ml-4 flex-shrink-0">
                  <div className={`w-2.5 h-2.5 rounded-full ${
                    event.category === "work" ? "bg-primary" :
                    event.category === "personal" ? "bg-green-500" :
                    "bg-amber-500"
                  }`}></div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8">
            <p className="text-gray-500">No events scheduled for this day</p>
            <Button variant="outline" className="mt-4">
              Add Event
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
