import { useState } from "react";
import { CheckCircleIcon, MapPinIcon, CalendarPlusIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Recommendation } from "@/types";
import { useToast } from "@/hooks/use-toast";

interface RecommendationsListProps {
  recommendations: Recommendation[];
  onHover: (id: string | null) => void;
  activeRecommendation: string | null;
}

export default function RecommendationsList({ 
  recommendations, 
  onHover,
  activeRecommendation
}: RecommendationsListProps) {
  const [activeTab, setActiveTab] = useState("restaurants");
  const { toast } = useToast();
  
  const filteredRecommendations = recommendations.filter(
    rec => {
      if (activeTab === "restaurants") return rec.category === "restaurant";
      if (activeTab === "events") return rec.category === "event";
      if (activeTab === "transport") return rec.category === "transport";
      return true;
    }
  );

  const handleAddToPlan = (name: string) => {
    toast({
      title: "Added to plan",
      description: `${name} has been added to your plan`,
      duration: 3000,
    });
  };

  const handleShowDirections = (name: string) => {
    toast({
      title: "Directions",
      description: `Getting directions to ${name}`,
      duration: 3000,
    });
  };

  return (
    <div className="space-y-4">
      <Tabs defaultValue="restaurants" className="bg-white rounded-lg shadow-sm overflow-hidden">
        <TabsList className="w-full border-b border-gray-200 rounded-none bg-transparent">
          <TabsTrigger 
            value="restaurants" 
            className="flex-1 data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:shadow-none rounded-none"
            onClick={() => setActiveTab("restaurants")}
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="mr-1.5 h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clipRule="evenodd" />
            </svg>
            Restaurants
          </TabsTrigger>
          <TabsTrigger 
            value="events" 
            className="flex-1 data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:shadow-none rounded-none"
            onClick={() => setActiveTab("events")}
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="mr-1.5 h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clipRule="evenodd" />
            </svg>
            Events
          </TabsTrigger>
          <TabsTrigger 
            value="transport" 
            className="flex-1 data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:shadow-none rounded-none"
            onClick={() => setActiveTab("transport")}
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="mr-1.5 h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
              <path d="M8 16.5a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zM15 16.5a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0z" />
              <path d="M3 4a1 1 0 00-1 1v10a1 1 0 001 1h1.05a2.5 2.5 0 014.9 0H10a1 1 0 001-1v-1h3.05a2.5 2.5 0 014.9 0H19a1 1 0 001-1v-6a1 1 0 00-.293-.707l-2-2A1 1 0 0017 4H3z" />
            </svg>
            Transport
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="restaurants" className="p-4 space-y-4">
          {filteredRecommendations.length > 0 ? (
            filteredRecommendations.map((recommendation, index) => (
              <RecommendationCard 
                key={recommendation.id}
                recommendation={recommendation}
                index={index}
                onHover={onHover}
                isActive={activeRecommendation === recommendation.id}
                onAddToPlan={handleAddToPlan}
                onShowDirections={handleShowDirections}
              />
            ))
          ) : (
            <div className="text-center py-8">
              <p className="text-gray-500">No restaurant recommendations available</p>
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="events" className="p-4 space-y-4">
          {filteredRecommendations.length > 0 ? (
            filteredRecommendations.map((recommendation, index) => (
              <RecommendationCard 
                key={recommendation.id}
                recommendation={recommendation}
                index={index}
                onHover={onHover}
                isActive={activeRecommendation === recommendation.id}
                onAddToPlan={handleAddToPlan}
                onShowDirections={handleShowDirections}
              />
            ))
          ) : (
            <div className="text-center py-8">
              <p className="text-gray-500">No event recommendations available</p>
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="transport" className="p-4 space-y-4">
          {filteredRecommendations.length > 0 ? (
            filteredRecommendations.map((recommendation, index) => (
              <RecommendationCard 
                key={recommendation.id}
                recommendation={recommendation}
                index={index}
                onHover={onHover}
                isActive={activeRecommendation === recommendation.id}
                onAddToPlan={handleAddToPlan}
                onShowDirections={handleShowDirections}
              />
            ))
          ) : (
            <div className="text-center py-8">
              <p className="text-gray-500">No transport recommendations available</p>
            </div>
          )}
        </TabsContent>
        
        <div className="px-4 py-3 bg-gray-50 border-t border-gray-200 text-right">
          <Button variant="link" className="text-primary hover:text-indigo-700">
            View all recommendations
            <svg xmlns="http://www.w3.org/2000/svg" className="ml-1 h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd" />
            </svg>
          </Button>
        </div>
      </Tabs>
    </div>
  );
}

interface RecommendationCardProps {
  recommendation: Recommendation;
  index: number;
  onHover: (id: string | null) => void;
  isActive: boolean;
  onAddToPlan: (name: string) => void;
  onShowDirections: (name: string) => void;
}

function RecommendationCard({ 
  recommendation, 
  index, 
  onHover,
  isActive,
  onAddToPlan,
  onShowDirections
}: RecommendationCardProps) {
  return (
    <div 
      className={`recommendation-card border rounded-lg p-4 hover:border-primary transition-colors duration-200 ${
        isActive ? "border-primary bg-indigo-50" : "border-gray-200"
      }`}
      onMouseEnter={() => onHover(recommendation.id)}
      onMouseLeave={() => onHover(null)}
    >
      <div className="flex justify-between items-start">
        <div>
          <div className="flex items-center">
            <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center text-white text-sm mr-2">
              {index + 1}
            </div>
            <h3 className="font-medium">{recommendation.name}</h3>
          </div>
          <div className="flex items-center mt-1 text-sm">
            <div className="text-amber-500 flex">
              {Array.from({ length: Math.floor(recommendation.rating) }).map((_, i) => (
                <svg key={i} xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" viewBox="0 0 20 20" fill="currentColor">
                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                </svg>
              ))}
              {recommendation.rating % 1 !== 0 && (
                <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" viewBox="0 0 20 20" fill="currentColor">
                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                </svg>
              )}
            </div>
            <span className="ml-1 text-gray-600">{recommendation.rating.toFixed(1)} ({recommendation.reviewCount})</span>
          </div>
        </div>
        <div className="text-xs bg-green-100 text-green-800 px-2 py-0.5 rounded-full">
          {recommendation.priceLevel}
        </div>
      </div>
      
      <div className="mt-2 text-sm text-gray-600">
        <p>{recommendation.cuisine} • {recommendation.distance} mi</p>
        <p className="mt-1">{recommendation.description}</p>
      </div>
      
      <div className="mt-3 flex items-center justify-between">
        <div className="text-xs text-primary flex items-center">
          <CheckCircleIcon className="h-3 w-3 mr-1" /> Matches your preferences
        </div>
        <div className="space-x-2">
          <Button 
            variant="outline" 
            size="sm" 
            className="text-xs h-7 px-2 py-0"
            onClick={() => onShowDirections(recommendation.name)}
          >
            <MapPinIcon className="h-3 w-3 mr-1" /> Directions
          </Button>
          <Button 
            size="sm" 
            className="text-xs h-7 px-2 py-0"
            onClick={() => onAddToPlan(recommendation.name)}
          >
            <CalendarPlusIcon className="h-3 w-3 mr-1" /> Add to plan
          </Button>
        </div>
      </div>
    </div>
  );
}
