# DayGenie - AI Travel Assistant

DayGenie is an AI-powered travel planning application that provides personalized recommendations based on your calendar and preferences. The application uses a multi-agent system to analyze your schedule and suggest activities, restaurants, and transportation options.

## System Architecture

The application consists of two main components:

1. **Frontend**: A React/TypeScript application that provides the user interface.
2. **Backend**: A dual-backend system with:
   - An Express.js API for serving the frontend and handling basic requests
   - A FastAPI Python backend for AI agent operations

## Setup Instructions

### Prerequisites

- Node.js (v16+)
- Python (3.10+)
- npm or yarn
- pip

### Installation

#### Clone the Repository

```bash
git clone <repository-url>
cd daygenie
```

#### Install Frontend Dependencies

```bash
npm install
```

#### Install Python Dependencies

```bash
cd python_backend
pip install fastapi uvicorn pydantic python-dotenv requests openai langchain
cd ..
```

### Running the Application

#### Option 1: Run Frontend and Backend Separately

Start the Python FastAPI backend:

```bash
cd python_backend
python main.py
```

In a separate terminal, start the Express/React frontend:

```bash
npm run dev
```

#### Option 2: Run Both Services Together

```bash
chmod +x start_services.sh
./start_services.sh
```

### Access the Application

- Frontend: [http://localhost:3000](http://localhost:3000)
- FastAPI Backend: [http://localhost:8000](http://localhost:8000)
- FastAPI Docs: [http://localhost:8000/docs](http://localhost:8000/docs)

## Key Features

- **Calendar Integration**: View your schedule and plan around your existing commitments
- **Personalized Recommendations**: Get suggestions tailored to your preferences and schedule
- **Map Integration**: Visualize recommendations on an interactive map
- **Preference Management**: Save and update your travel preferences

## Development Notes

### Adding New Frontend Components

1. Create component in `client/src/components/`
2. Import and use in relevant page or other component

### Modifying Python Agents

1. Agent logic is located in `python_backend/agents/`
2. After modifying agent code, restart the FastAPI server

### Local vs Replit Development

This project can be developed both locally in environments like VS Code and in Replit:

- **Local Development**: Follow the setup instructions above
- **Replit Development**: The project comes preconfigured with the correct Replit configuration

## Project Structure

```
├── api                    # Express API routes (when not using FastAPI)
├── client                 # React frontend
│   ├── src
│   │   ├── components     # UI components
│   │   ├── hooks          # Custom React hooks
│   │   ├── lib            # Utility functions
│   │   ├── pages          # Page components
│   │   └── types          # TypeScript type definitions
├── python_backend         # Python FastAPI backend
│   ├── agents             # AI agent implementations
│   └── main.py            # FastAPI application entry point
├── server                 # Express server configuration
└── shared                 # Shared code between frontend and backend
```

## Technology Stack

- **Frontend**: React, TypeScript, TailwindCSS, Shadcn/UI
- **State Management**: React Query, React Context API
- **Backend**: Express.js (Node.js), FastAPI (Python)
- **AI Framework**: LangChain, OpenAI
- **Styling**: TailwindCSS, Shadcn/UI components

## License

[MIT License](LICENSE)