import { useState } from "react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { PlusIcon, CheckIcon, Calendar as CalendarIcon } from "lucide-react";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tag, TagInput } from "@/components/ui/tag-input";
import { useToast } from "@/hooks/use-toast";
import { Calendar } from "@/components/ui/calendar";
import { 
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { format, addDays } from "date-fns";

const formSchema = z.object({
  travelPurpose: z.string(),
  transportation: z.string(),
  budget: z.number().min(1).max(5),
  destination: z.string(),
  startDate: z.date(),
  endDate: z.date(),
});

type FormValues = z.infer<typeof formSchema>;

const budgetLabels: Record<number, string> = {
  1: "Budget",
  2: "Economy",
  3: "Medium",
  4: "Premium",
  5: "Luxury",
};

const destinations = [
  "New York", "Los Angeles", "Chicago", "Miami", "Las Vegas", 
  "San Francisco", "Seattle", "Boston", "Washington DC", 
  "New Orleans", "Austin", "Denver", "Portland"
];

interface PreferencesFormProps {
  onSubmit: (values: FormValues, foodPreferences: Tag[], activityInterests: Tag[]) => void;
}

export default function PreferencesForm({ onSubmit }: PreferencesFormProps) {
  const [foodPreferences, setFoodPreferences] = useState<Tag[]>([
    { id: "1", text: "Italian" },
    { id: "2", text: "Vegetarian" },
  ]);
  
  const [activityInterests, setActivityInterests] = useState<Tag[]>([
    { id: "1", text: "Museums" },
    { id: "2", text: "Live Music" },
    { id: "3", text: "Parks" },
  ]);

  const [isConnectingCalendar, setIsConnectingCalendar] = useState(false);
  const [isCalendarConnected, setIsCalendarConnected] = useState(false);
  const [canAddToCalendar, setCanAddToCalendar] = useState(false);
  const [isAddingToCalendar, setIsAddingToCalendar] = useState(false);

  const { toast } = useToast();

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      travelPurpose: "Business",
      transportation: "Public Transit",
      budget: 3,
      destination: "New York",
      startDate: new Date(),
      endDate: addDays(new Date(), 3),
    },
  });

  const handleSubmit = (values: FormValues) => {
    onSubmit(values, foodPreferences, activityInterests);
    toast({
      title: "Generating recommendations",
      description: "Please wait while we analyze your preferences",
      duration: 3000,
    });
  };

  const handleConnectCalendar = () => {
    setIsConnectingCalendar(true);
    
    // Immediately set as connected since this is a demo
    setTimeout(() => {
      setIsConnectingCalendar(false);
      setIsCalendarConnected(true);
      
      // Show success toast 
      toast({
        title: "Calendar connected successfully",
        description: "Demo calendar data has been loaded",
        variant: "default",
        duration: 3000,
      });
      
      // No need for real OAuth flow in our demo
    }, 500);
  };

  return (
    <div className="mb-12 bg-white rounded-lg shadow-sm p-6 sm:p-8">
      <h2 className="text-2xl font-bold mb-6">Tell us about your preferences</h2>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(handleSubmit)}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <FormField
              control={form.control}
              name="travelPurpose"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-medium text-gray-700">Travel Purpose</FormLabel>
                  <Select
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Select purpose" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="Business">Business</SelectItem>
                      <SelectItem value="Leisure">Leisure</SelectItem>
                      <SelectItem value="Family Visit">Family Visit</SelectItem>
                      <SelectItem value="Adventure">Adventure</SelectItem>
                      <SelectItem value="Cultural Experience">Cultural Experience</SelectItem>
                    </SelectContent>
                  </Select>
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="destination"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-medium text-gray-700">Travel Destination</FormLabel>
                  <Select
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Select destination" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {destinations.map((destination) => (
                        <SelectItem key={destination} value={destination}>
                          {destination}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="transportation"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-medium text-gray-700">Preferred Transportation</FormLabel>
                  <Select
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Select transportation" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="Public Transit">Public Transit</SelectItem>
                      <SelectItem value="Rideshare">Rideshare</SelectItem>
                      <SelectItem value="Car Rental">Car Rental</SelectItem>
                      <SelectItem value="Walking">Walking</SelectItem>
                      <SelectItem value="Cycling">Cycling</SelectItem>
                    </SelectContent>
                  </Select>
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="startDate"
              render={({ field }) => (
                <FormItem className="flex flex-col">
                  <FormLabel className="text-sm font-medium text-gray-700">Travel Start Date</FormLabel>
                  <Popover>
                    <PopoverTrigger asChild>
                      <FormControl>
                        <Button
                          variant={"outline"}
                          className="w-full pl-3 text-left font-normal flex justify-between items-center"
                        >
                          {field.value ? (
                            format(field.value, "PPP")
                          ) : (
                            <span>Select start date</span>
                          )}
                          <CalendarIcon className="h-4 w-4 opacity-50" />
                        </Button>
                      </FormControl>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={field.value}
                        onSelect={field.onChange}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="endDate"
              render={({ field }) => (
                <FormItem className="flex flex-col">
                  <FormLabel className="text-sm font-medium text-gray-700">Travel End Date</FormLabel>
                  <Popover>
                    <PopoverTrigger asChild>
                      <FormControl>
                        <Button
                          variant={"outline"}
                          className="w-full pl-3 text-left font-normal flex justify-between items-center"
                        >
                          {field.value ? (
                            format(field.value, "PPP")
                          ) : (
                            <span>Select end date</span>
                          )}
                          <CalendarIcon className="h-4 w-4 opacity-50" />
                        </Button>
                      </FormControl>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={field.value}
                        onSelect={field.onChange}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormItem>
              <FormLabel className="text-sm font-medium text-gray-700">Food Preferences</FormLabel>
              <TagInput
                placeholder="Add food preference..."
                tags={foodPreferences}
                setTags={setFoodPreferences}
                className="mt-1"
              />
            </FormItem>
            
            <FormField
              control={form.control}
              name="budget"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-medium text-gray-700">Budget Level</FormLabel>
                  <div className="flex items-center gap-4">
                    <FormControl>
                      <Slider
                        min={1}
                        max={5}
                        step={1}
                        value={[field.value]}
                        onValueChange={(value) => field.onChange(value[0])}
                        className="w-full"
                      />
                    </FormControl>
                    <span className="text-sm font-medium text-gray-600">
                      {budgetLabels[field.value]}
                    </span>
                  </div>
                </FormItem>
              )}
            />
            
            <div className="md:col-span-2">
              <FormLabel className="text-sm font-medium text-gray-700">Activity Interests</FormLabel>
              <TagInput
                placeholder="Add activity interest..."
                tags={activityInterests}
                setTags={setActivityInterests}
                className="mt-1"
              />
            </div>
            
            <div className="md:col-span-2">
              <div className="flex flex-col rounded-lg border border-gray-200 p-4">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center">
                    <svg viewBox="0 0 24 24" className="w-6 h-6 mr-3 text-[#4285F4]">
                      <path
                        fill="currentColor"
                        d="M12.545,10.239v3.821h5.445c-0.712,2.315-2.647,3.972-5.445,3.972c-3.332,0-6.033-2.701-6.033-6.032 s2.701-6.032,6.033-6.032c1.498,0,2.866,0.549,3.921,1.453l2.814-2.814C17.503,2.988,15.139,2,12.545,2 C7.021,2,2.543,6.477,2.543,12s4.478,10,10.002,10c8.396,0,10.249-7.85,9.426-11.748L12.545,10.239z"
                      />
                    </svg>
                    <div>
                      <h3 className="text-lg font-medium">Google Calendar Integration</h3>
                      <p className="text-sm text-gray-500">ExploreEase AI can analyze your schedule and add events to your calendar</p>
                    </div>
                  </div>
                </div>
                
                <div className="flex flex-col sm:flex-row gap-3 sm:justify-start">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={handleConnectCalendar}
                    disabled={isConnectingCalendar || isCalendarConnected}
                    className={isCalendarConnected ? "bg-green-100 border-green-600 text-green-700 hover:bg-green-200" : ""}
                  >
                    {isConnectingCalendar ? (
                      "Connecting..."
                    ) : isCalendarConnected ? (
                      <>
                        <CheckIcon className="mr-2 h-4 w-4" /> Connected to Calendar
                      </>
                    ) : (
                      <>
                        <CalendarIcon className="mr-2 h-4 w-4" /> Connect Calendar
                      </>
                    )}
                  </Button>
                  
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setIsAddingToCalendar(true);
                      toast({
                        title: "Adding to calendar",
                        description: "Your travel plan will be added to your Google Calendar",
                        duration: 3000,
                      });
                      setTimeout(() => {
                        setIsAddingToCalendar(false);
                        toast({
                          title: "Added to calendar",
                          description: "Your travel plan has been added to your Google Calendar",
                          variant: "default",
                          duration: 3000,
                        });
                      }, 1500);
                    }}
                    disabled={!isCalendarConnected || isAddingToCalendar}
                  >
                    {isAddingToCalendar ? "Adding to Calendar..." : "Add to Calendar"}
                  </Button>
                </div>
              </div>
            </div>
          </div>
          
          <div className="mt-8 flex justify-end">
            <Button type="submit" className="bg-primary hover:bg-indigo-700 px-6 py-3">
              Generate Recommendations
              <svg xmlns="http://www.w3.org/2000/svg" className="ml-2 h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M5 2a1 1 0 011 1v1h1a1 1 0 010 2H6v1a1 1 0 01-2 0V6H3a1 1 0 010-2h1V3a1 1 0 011-1zm0 10a1 1 0 011 1v1h1a1 1 0 110 2H6v1a1 1 0 11-2 0v-1H3a1 1 0 110-2h1v-1a1 1 0 011-1zM12 2a1 1 0 01.967.744L14.146 7.2 17.5 9.134a1 1 0 010 1.732l-3.354 1.935-1.18 4.455a1 1 0 01-1.933 0L9.854 12.8 6.5 10.866a1 1 0 010-1.732l3.354-1.935 1.18-4.455A1 1 0 0112 2z" clipRule="evenodd" />
              </svg>
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
}
