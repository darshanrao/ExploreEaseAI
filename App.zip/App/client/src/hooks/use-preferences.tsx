import { useState } from 'react';
import { Tag } from '@/components/ui/tag-input';

export function usePreferences() {
  const [travelPurpose, setTravelPurpose] = useState('Business');
  const [transportation, setTransportation] = useState('Public Transit');
  const [foodPreferences, setFoodPreferences] = useState<Tag[]>([
    { id: '1', text: 'Italian' },
    { id: '2', text: 'Vegetarian' },
  ]);
  const [budget, setBudget] = useState(3);
  const [activityInterests, setActivityInterests] = useState<Tag[]>([
    { id: '1', text: 'Museums' },
    { id: '2', text: 'Live Music' },
    { id: '3', text: 'Parks' },
  ]);
  const [isCalendarConnected, setIsCalendarConnected] = useState(false);

  return {
    travelPurpose,
    setTravelPurpose,
    transportation,
    setTransportation,
    foodPreferences,
    setFoodPreferences,
    budget,
    setBudget,
    activityInterests,
    setActivityInterests,
    isCalendarConnected,
    setIsCalendarConnected,
  };
}
