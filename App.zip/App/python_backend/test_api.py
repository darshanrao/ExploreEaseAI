import requests
import json

# Base URL for the API
base_url = "http://localhost:8000"

def test_health():
    """Test the health endpoint"""
    response = requests.get(f"{base_url}/api/health")
    print("Health Check Response:", response.status_code)
    print(response.json())
    print()

def test_recommendations():
    """Test the recommendations endpoint"""
    # Sample preferences data
    preferences = {
        "travelPurpose": "business",
        "transportation": "public",
        "budget": 100,
        "foodPreferences": [
            {"id": "1", "text": "Italian"},
            {"id": "2", "text": "Vegetarian"}
        ],
        "activityInterests": [
            {"id": "1", "text": "Museums"},
            {"id": "2", "text": "Sightseeing"}
        ],
        "date": "2025-03-31"
    }
    
    # Make the request
    response = requests.post(
        f"{base_url}/api/recommendations",
        json=preferences
    )
    
    print("Recommendations Response:", response.status_code)
    if response.status_code == 200:
        recommendations = response.json()
        print(f"Received {len(recommendations.get('recommendations', []))} recommendations")
        print(json.dumps(recommendations, indent=2))
    else:
        print("Error:", response.text)
    print()

def test_calendar_events():
    """Test the calendar events endpoint"""
    response = requests.get(f"{base_url}/api/calendar-events")
    
    print("Calendar Events Response:", response.status_code)
    if response.status_code == 200:
        events = response.json()
        print(f"Received {len(events.get('events', []))} events")
        print(json.dumps(events, indent=2))
    else:
        print("Error:", response.text)
    print()

if __name__ == "__main__":
    print("Testing FastAPI Endpoints...")
    test_health()
    test_recommendations()
    test_calendar_events()
    print("All tests completed.")