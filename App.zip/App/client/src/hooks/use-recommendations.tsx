import { useState } from 'react';
import { Recommendation, PreferencesSubmitData } from '@/types';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

export function useRecommendations() {
  const [recommendations, setRecommendations] = useState<Recommendation[]>([]);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const handleSubmitPreferences = async (data: PreferencesSubmitData) => {
    try {
      setLoading(true);
      
      // Request gets proxied to FastAPI backend by Express
      const response = await apiRequest('POST', '/api/recommendations', data);
      
      if (!response.ok) {
        throw new Error('API request failed');
      }
      
      const result = await response.json();
      setRecommendations(result.recommendations);
      
      setLoading(false);
      toast({
        title: 'Recommendations ready',
        description: 'We\'ve found some great places based on your preferences!',
        variant: 'default',
      });
    } catch (error) {
      console.error('Failed to get recommendations:', error);
      toast({
        title: 'Error getting recommendations',
        description: 'Failed to generate recommendations. Please try again.',
        variant: 'destructive',
      });
      setLoading(false);
    }
  };

  return {
    recommendations,
    loading,
    handleSubmitPreferences
  };
}
