import * as React from "react";
import { X } from "lucide-react";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export interface Tag {
  id: string;
  text: string;
}

interface TagInputProps {
  placeholder?: string;
  tags: Tag[];
  setTags: React.Dispatch<React.SetStateAction<Tag[]>>;
  disabled?: boolean;
  onTagAdd?: (tag: Tag) => void;
  onTagRemove?: (id: string) => void;
  className?: string;
}

export function TagInput({
  placeholder = "Add item...",
  tags,
  setTags,
  disabled = false,
  onTagAdd,
  onTagRemove,
  className,
}: TagInputProps) {
  const [inputValue, setInputValue] = React.useState("");
  const inputRef = React.useRef<HTMLInputElement>(null);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputValue(e.target.value);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" && inputValue.trim() !== "") {
      e.preventDefault();
      const newTag = { id: crypto.randomUUID(), text: inputValue.trim() };
      setTags((prev) => [...prev, newTag]);
      if (onTagAdd) onTagAdd(newTag);
      setInputValue("");
    }
  };

  const removeTag = (id: string) => {
    setTags((prev) => prev.filter((tag) => tag.id !== id));
    if (onTagRemove) onTagRemove(id);
  };

  return (
    <div
      className={cn(
        "flex flex-wrap gap-2 p-1 border border-input bg-background rounded-md",
        className
      )}
      onClick={() => inputRef.current?.focus()}
    >
      {tags.map((tag) => (
        <Badge
          key={tag.id}
          variant="secondary"
          className="bg-indigo-100 text-primary hover:bg-indigo-200"
        >
          {tag.text}
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={() => removeTag(tag.id)}
            className="ml-1 h-auto p-0 text-indigo-400 hover:text-indigo-600"
            disabled={disabled}
          >
            <X className="h-3 w-3" />
            <span className="sr-only">Remove tag</span>
          </Button>
        </Badge>
      ))}
      <Input
        ref={inputRef}
        type="text"
        placeholder={placeholder}
        value={inputValue}
        onChange={handleInputChange}
        onKeyDown={handleKeyDown}
        className="flex-1 h-8 min-w-24 border-0 p-0 pl-2 focus-visible:ring-0 focus-visible:ring-offset-0"
        disabled={disabled}
      />
    </div>
  );
}
