#!/bin/bash

# Make scripts executable
chmod +x run_python_backend.sh

# Start the FastAPI backend server using the dedicated script
echo "Starting FastAPI backend on port 8000..."
./run_python_backend.sh &
FASTAPI_PID=$!

# Start the Node.js frontend server
echo "Starting Node.js frontend on port 5000..."
npm run dev &
FRONTEND_PID=$!

# Handle cleanup on exit
cleanup() {
  echo "Stopping servers..."
  kill $FASTAPI_PID
  kill $FRONTEND_PID
  exit
}

# Register cleanup function for SIGINT (Ctrl+C)
trap cleanup SIGINT

# Wait a moment to ensure backends start correctly
sleep 5

# Check if FastAPI backend is running
echo "Checking FastAPI backend health..."
curl -s http://localhost:8000/api/health || echo "Warning: FastAPI backend may not be running correctly"

# Keep script running
echo "Servers are running. Press Ctrl+C to stop."
wait