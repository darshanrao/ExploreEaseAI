import { AlertCircle } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";

export default function BackendAlert() {
  return (
    <Alert variant="destructive" className="mb-6">
      <AlertCircle className="h-4 w-4" />
      <AlertTitle>AI Backend Not Running</AlertTitle>
      <AlertDescription className="mt-2">
        <p className="mb-2">
          The ExploreEase AI backend appears to be unavailable. To use all features, please start the Python backend with:
        </p>
        <div className="bg-black/90 text-white p-2 rounded font-mono text-sm mb-2">
          ./run_python_backend.sh
        </div>
        <p>
          This will enable AI-powered recommendations and calendar features.
        </p>
        <Button 
          variant="outline" 
          onClick={() => window.location.reload()}
          className="mt-3"
        >
          Retry Connection
        </Button>
      </AlertDescription>
    </Alert>
  );
}