import { useState, useEffect } from "react";
import { Filter } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import PreferencesForm from "@/components/preferences/PreferencesForm";
import CalendarView from "@/components/calendar/CalendarView";
import MapView from "@/components/recommendations/MapView";
import RecommendationsList from "@/components/recommendations/RecommendationsList";
import AgentExplanation from "@/components/recommendations/AgentExplanation";
import BackendAlert from "@/components/common/BackendAlert";
import { useCalendarEvents } from "@/hooks/use-calendar";
import { useRecommendations } from "@/hooks/use-recommendations";
import { Tag } from "@/components/ui/tag-input";

export default function Home() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [activeRecommendation, setActiveRecommendation] = useState<string | null>(null);
  const [sortOption, setSortOption] = useState("relevance");
  const [backendStatus, setBackendStatus] = useState<'checking' | 'available' | 'unavailable'>('checking');
  
  // Check if both Express and Python backend are available
  useEffect(() => {
    const checkBackend = async () => {
      try {
        // First check if Express is running
        const expressResponse = await fetch('/api/health-check');
        if (!expressResponse.ok) {
          setBackendStatus('unavailable');
          return;
        }
        
        // Then check if Python backend is running
        const pythonResponse = await fetch('/api/python-health');
        if (pythonResponse.ok) {
          const data = await pythonResponse.json();
          if (data.python === true) {
            setBackendStatus('available');
          } else {
            setBackendStatus('unavailable');
          }
        } else {
          setBackendStatus('unavailable');
        }
      } catch (error) {
        console.error('Backend health check failed:', error);
        setBackendStatus('unavailable');
      }
    };
    
    checkBackend();
    // Check every 15 seconds
    const interval = setInterval(checkBackend, 15000);
    return () => clearInterval(interval);
  }, []);
  
  const { events } = useCalendarEvents(currentDate);
  const { recommendations, loading, handleSubmitPreferences } = useRecommendations();

  const handlePreferencesSubmit = (
    values: { 
      travelPurpose: string; 
      transportation: string; 
      budget: number;
      destination: string;
      startDate: Date;
      endDate: Date;
    }, 
    foodPreferences: Tag[], 
    activityInterests: Tag[]
  ) => {
    handleSubmitPreferences({
      ...values,
      foodPreferences: foodPreferences.map(tag => tag.text),
      activityInterests: activityInterests.map(tag => tag.text),
      startDate: values.startDate.toISOString(),
      endDate: values.endDate.toISOString()
    });
  };

  return (
    <>
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-primary to-indigo-800 text-white py-12 sm:py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-3xl sm:text-4xl font-display font-bold mb-3">ExploreEase AI Travel Assistant</h1>
            <p className="text-lg max-w-2xl mx-auto opacity-90">Smart travel recommendations powered by AI agents that sync perfectly with your calendar.</p>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {backendStatus === 'unavailable' && <BackendAlert />}
        
        {/* Preferences Form */}
        <PreferencesForm onSubmit={handlePreferencesSubmit} />
        
        {/* Calendar View */}
        <CalendarView 
          events={events} 
          currentDate={currentDate} 
          onDateChange={setCurrentDate} 
        />
        
        {/* Recommendations Header */}
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-2xl font-bold">Your Personalized Recommendations</h2>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm">
              <Filter className="h-4 w-4 mr-1.5" /> Filter
            </Button>
            <Select
              value={sortOption}
              onValueChange={setSortOption}
            >
              <SelectTrigger className="w-[180px] h-9">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="relevance">Sort by: Relevance</SelectItem>
                <SelectItem value="distance">Sort by: Distance</SelectItem>
                <SelectItem value="rating">Sort by: Rating</SelectItem>
                <SelectItem value="price">Sort by: Price</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        
        {/* Map and Recommendations */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-12">
          {/* Map Section */}
          <div className="lg:col-span-2">
            <MapView 
              recommendations={recommendations} 
              activeRecommendation={activeRecommendation}
              onRecommendationHover={setActiveRecommendation}
            />
          </div>
          
          {/* Recommendations List */}
          <div className="space-y-4">
            <RecommendationsList 
              recommendations={recommendations}
              onHover={setActiveRecommendation}
              activeRecommendation={activeRecommendation}
            />
            
            {/* Agent Explanation */}
            <AgentExplanation />
          </div>
        </div>
      </main>
    </>
  );
}
