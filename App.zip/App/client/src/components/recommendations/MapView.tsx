import { useEffect, useState } from "react";
import { Plus, Minus } from "lucide-react";
import { Recommendation } from "@/types";

interface MapViewProps {
  recommendations: Recommendation[];
  activeRecommendation: string | null;
  onRecommendationHover: (id: string | null) => void;
}

export default function MapView({ recommendations, activeRecommendation, onRecommendationHover }: MapViewProps) {
  const [isMapLoaded, setIsMapLoaded] = useState(false);
  const [selectedPin, setSelectedPin] = useState<string | null>(null);

  // Set map as loaded immediately
  useEffect(() => {
    setIsMapLoaded(true);
  }, []);

  useEffect(() => {
    if (activeRecommendation) {
      setSelectedPin(activeRecommendation);
    }
  }, [activeRecommendation]);

  const handlePinClick = (id: string) => {
    setSelectedPin(id === selectedPin ? null : id);
    onRecommendationHover(id === selectedPin ? null : id);
  };

  const categoryColors: Record<string, string> = {
    restaurant: "bg-primary",
    event: "bg-amber-500",
    transport: "bg-green-500",
    attraction: "bg-purple-500",
    default: "bg-gray-500"
  };

  // Function to get a deterministic position for each pin
  const getPinPosition = (index: number, id: string) => {
    // Use a simple algorithm based on the id's characters to create a stable position
    const charSum = id.split('').reduce((sum, char) => sum + char.charCodeAt(0), 0);
    
    // Create positions between 10% and 90% of the container
    const left = 10 + (((charSum % 8) * 10) + (index * 5)) % 80;
    const top = 10 + (((charSum % 12) * 8) + (index * 7)) % 80;
    
    return { left, top };
  };

  return (
    <div className="bg-white rounded-lg shadow-sm overflow-hidden h-full">
      <div className="relative h-[500px]">
        {/* Map Background - Use a gradient instead of an image for reliability */}
        <div 
          className="absolute inset-0 bg-gradient-to-br from-gray-100 to-gray-300"
        ></div>
        
        {/* Map Grid Lines for visual interest */}
        <div className="absolute inset-0 grid grid-cols-8 grid-rows-8">
          {Array.from({ length: 64 }).map((_, i) => (
            <div key={i} className="border border-gray-200 opacity-30"></div>
          ))}
        </div>
        
        {/* Loading State */}
        {!isMapLoaded && (
          <div className="absolute inset-0 flex items-center justify-center bg-white bg-opacity-75">
            <div className="flex flex-col items-center">
              <svg className="animate-spin h-8 w-8 text-primary mb-2" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              <span className="text-gray-600">Loading map...</span>
            </div>
          </div>
        )}
        
        {/* Recommendation Pins */}
        {isMapLoaded && recommendations.map((rec, index) => {
          // Get stable positions
          const { left, top } = getPinPosition(index, rec.id);
          const color = categoryColors[rec.category] || categoryColors.default;
          
          return (
            <div 
              key={rec.id}
              className="absolute"
              style={{ left: `${left}%`, top: `${top}%` }}
              onMouseEnter={() => onRecommendationHover(rec.id)}
              onMouseLeave={() => onRecommendationHover(null)}
            >
              <div className="relative">
                <div 
                  className={`w-8 h-8 ${color} rounded-full flex items-center justify-center text-white shadow-lg cursor-pointer transform transition-transform ${activeRecommendation === rec.id ? 'scale-125' : ''}`}
                  onClick={() => handlePinClick(rec.id)}
                >
                  {index + 1}
                </div>
                
                {selectedPin === rec.id && (
                  <div className="absolute bottom-full mb-2 w-48 bg-white rounded-lg shadow-lg p-3 transform -translate-x-1/2 left-1/2 z-10">
                    <h4 className="font-medium text-gray-900">{rec.name}</h4>
                    <div className="flex items-center mt-1 text-sm">
                      <span className="text-amber-500 font-bold mr-1">★</span>
                      <span className="text-gray-600">{rec.rating.toFixed(1)} ({rec.reviewCount})</span>
                    </div>
                    <p className="text-xs text-gray-500 mt-1">{rec.description.slice(0, 60)}...</p>
                  </div>
                )}
              </div>
            </div>
          );
        })}
        
        {/* Map Controls */}
        <div className="absolute bottom-4 right-4 flex flex-col gap-2">
          <button className="w-8 h-8 bg-white rounded-full shadow-md flex items-center justify-center text-gray-700 hover:bg-gray-100">
            <Plus className="h-4 w-4" />
          </button>
          <button className="w-8 h-8 bg-white rounded-full shadow-md flex items-center justify-center text-gray-700 hover:bg-gray-100">
            <Minus className="h-4 w-4" />
          </button>
        </div>
        
        {/* Map Attribution */}
        <div className="absolute bottom-2 left-2 text-xs text-gray-600 bg-white bg-opacity-75 px-2 py-1 rounded">
          Demo Map - Pins represent recommendation locations
        </div>
      </div>
      
      <div className="p-4 border-t border-gray-200">
        <div className="flex flex-wrap items-center gap-3 text-sm">
          <span className="text-gray-600 font-medium">Legend:</span>
          <span className="flex items-center">
            <span className="w-3 h-3 bg-primary rounded-full mr-1"></span>
            Restaurants
          </span>
          <span className="flex items-center">
            <span className="w-3 h-3 bg-amber-500 rounded-full mr-1"></span>
            Events
          </span>
          <span className="flex items-center">
            <span className="w-3 h-3 bg-green-500 rounded-full mr-1"></span>
            Transport
          </span>
          <span className="flex items-center">
            <span className="w-3 h-3 bg-purple-500 rounded-full mr-1"></span>
            Attractions
          </span>
        </div>
      </div>
    </div>
  );
}
